"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { CloudRain, Droplets, Thermometer, Wind, Gauge, ArrowRight } from "lucide-react"
import { PredictionResult } from "@/components/prediction-result"

export default function RainfallPredictionForm() {
  const [formData, setFormData] = useState({
    humidity: 75,
    temperature: 22,
    pressure: 1010,
    windSpeed: 15,
    cloudCover: 60,
  })

  const [prediction, setPrediction] = useState<number | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleSliderChange = (name: string, value: number[]) => {
    setFormData({
      ...formData,
      [name]: value[0],
    })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: Number.parseFloat(value) || 0,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call with dummy prediction algorithm
    setTimeout(() => {
      // Simple dummy algorithm: higher humidity and lower pressure increase rain chance
      const humidityFactor = formData.humidity * 0.6
      const temperatureFactor = Math.max(0, 30 - formData.temperature) * 1.5
      const pressureFactor = Math.max(0, 1015 - formData.pressure) * 0.5
      const windFactor = formData.windSpeed * 0.3
      const cloudFactor = formData.cloudCover * 0.4

      let calculatedPrediction = (humidityFactor + temperatureFactor + pressureFactor + windFactor + cloudFactor) / 3

      // Ensure prediction is between 0 and 100
      calculatedPrediction = Math.min(100, Math.max(0, calculatedPrediction))

      setPrediction(Math.round(calculatedPrediction))
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="humidity" className="flex items-center gap-2">
                <Droplets className="h-4 w-4 text-blue-500" />
                Humidity (%)
              </Label>
              <Input
                type="number"
                id="humidity"
                name="humidity"
                value={formData.humidity}
                onChange={handleInputChange}
                className="w-16 text-right"
                min="0"
                max="100"
              />
            </div>
            <Slider
              id="humidity-slider"
              value={[formData.humidity]}
              min={0}
              max={100}
              step={1}
              onValueChange={(value) => handleSliderChange("humidity", value)}
              className="py-2"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="temperature" className="flex items-center gap-2">
                <Thermometer className="h-4 w-4 text-red-500" />
                Temperature (°C)
              </Label>
              <Input
                type="number"
                id="temperature"
                name="temperature"
                value={formData.temperature}
                onChange={handleInputChange}
                className="w-16 text-right"
                min="-20"
                max="50"
              />
            </div>
            <Slider
              id="temperature-slider"
              value={[formData.temperature]}
              min={-20}
              max={50}
              step={1}
              onValueChange={(value) => handleSliderChange("temperature", value)}
              className="py-2"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="pressure" className="flex items-center gap-2">
                <Gauge className="h-4 w-4 text-purple-500" />
                Pressure (hPa)
              </Label>
              <Input
                type="number"
                id="pressure"
                name="pressure"
                value={formData.pressure}
                onChange={handleInputChange}
                className="w-16 text-right"
                min="950"
                max="1050"
              />
            </div>
            <Slider
              id="pressure-slider"
              value={[formData.pressure]}
              min={950}
              max={1050}
              step={1}
              onValueChange={(value) => handleSliderChange("pressure", value)}
              className="py-2"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="windSpeed" className="flex items-center gap-2">
                <Wind className="h-4 w-4 text-teal-500" />
                Wind Speed (km/h)
              </Label>
              <Input
                type="number"
                id="windSpeed"
                name="windSpeed"
                value={formData.windSpeed}
                onChange={handleInputChange}
                className="w-16 text-right"
                min="0"
                max="100"
              />
            </div>
            <Slider
              id="windSpeed-slider"
              value={[formData.windSpeed]}
              min={0}
              max={100}
              step={1}
              onValueChange={(value) => handleSliderChange("windSpeed", value)}
              className="py-2"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="cloudCover" className="flex items-center gap-2">
                <CloudRain className="h-4 w-4 text-gray-500" />
                Cloud Cover (%)
              </Label>
              <Input
                type="number"
                id="cloudCover"
                name="cloudCover"
                value={formData.cloudCover}
                onChange={handleInputChange}
                className="w-16 text-right"
                min="0"
                max="100"
              />
            </div>
            <Slider
              id="cloudCover-slider"
              value={[formData.cloudCover]}
              min={0}
              max={100}
              step={1}
              onValueChange={(value) => handleSliderChange("cloudCover", value)}
              className="py-2"
            />
          </div>
        </div>

        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? "Calculating..." : "Predict Rainfall"}
          {!isLoading && <ArrowRight className="ml-2 h-4 w-4" />}
        </Button>
      </form>

      {prediction !== null && (
        <div className="mt-6">
          <PredictionResult prediction={prediction} />
        </div>
      )}
    </div>
  )
}
