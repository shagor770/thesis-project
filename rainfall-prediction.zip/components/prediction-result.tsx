"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { CloudRain, CloudSun, Sun } from "lucide-react"

interface PredictionResultProps {
  prediction: number
}

export function PredictionResult({ prediction }: PredictionResultProps) {
  const [animate, setAnimate] = useState(false)

  useEffect(() => {
    setAnimate(true)
    const timer = setTimeout(() => setAnimate(false), 1000)
    return () => clearTimeout(timer)
  }, [prediction])

  const getIcon = () => {
    if (prediction > 70) {
      return <CloudRain className="h-12 w-12 text-blue-600" />
    } else if (prediction > 30) {
      return <CloudSun className="h-12 w-12 text-amber-500" />
    } else {
      return <Sun className="h-12 w-12 text-yellow-500" />
    }
  }

  const getMessage = () => {
    if (prediction > 70) {
      return "High chance of rainfall. Consider bringing an umbrella!"
    } else if (prediction > 30) {
      return "Moderate chance of rainfall. Be prepared for possible showers."
    } else {
      return "Low chance of rainfall. Likely to stay dry."
    }
  }

  const getColor = () => {
    if (prediction > 70) {
      return "from-blue-500 to-blue-700"
    } else if (prediction > 30) {
      return "from-amber-400 to-amber-600"
    } else {
      return "from-yellow-400 to-yellow-600"
    }
  }

  return (
    <Card className={`overflow-hidden transition-all duration-300 ${animate ? "scale-105" : "scale-100"}`}>
      <div className={`h-2 bg-gradient-to-r ${getColor()}`} />
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold">Rainfall Prediction</h3>
            <p className="text-gray-500">{getMessage()}</p>
          </div>
          <div className="flex flex-col items-center">
            {getIcon()}
            <div className="mt-2 text-2xl font-bold">{prediction}%</div>
          </div>
        </div>

        <div className="mt-4">
          <div className="relative h-4 w-full overflow-hidden rounded-full bg-gray-200">
            <div
              className={`absolute left-0 top-0 h-full rounded-full bg-gradient-to-r ${getColor()}`}
              style={{ width: `${prediction}%` }}
            />
          </div>
          <div className="mt-1 flex justify-between text-xs text-gray-500">
            <span>Low</span>
            <span>Medium</span>
            <span>High</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
