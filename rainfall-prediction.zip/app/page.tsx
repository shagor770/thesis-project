import RainfallPredictionForm from "@/components/rainfall-prediction-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-sky-50 to-white p-4 md:p-8 lg:p-12">
      <div className="mx-auto max-w-5xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 md:text-4xl">Weather Rainfall Prediction</h1>
          <p className="mt-3 text-lg text-gray-600">Enter weather parameters to predict rainfall probability</p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Input Parameters</CardTitle>
                <CardDescription>Enter the current weather conditions to predict rainfall</CardDescription>
              </CardHeader>
              <CardContent>
                <RainfallPredictionForm />
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Recent Predictions</CardTitle>
                <CardDescription>Historical prediction data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { date: "Today", humidity: 85, temp: 22, pressure: 1012, prediction: 78 },
                    { date: "Yesterday", humidity: 65, temp: 28, pressure: 1010, prediction: 32 },
                    { date: "2 days ago", humidity: 72, temp: 24, pressure: 1008, prediction: 45 },
                  ].map((item, i) => (
                    <div key={i} className="rounded-lg bg-gray-50 p-3">
                      <div className="flex justify-between">
                        <span className="font-medium">{item.date}</span>
                        <span className={`font-semibold ${item.prediction > 50 ? "text-blue-600" : "text-amber-600"}`}>
                          {item.prediction}% chance
                        </span>
                      </div>
                      <div className="mt-1 text-sm text-gray-500">
                        {item.humidity}% humidity, {item.temp}°C
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
